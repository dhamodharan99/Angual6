1. npm install bootstrap@4 jquery --save
2. 