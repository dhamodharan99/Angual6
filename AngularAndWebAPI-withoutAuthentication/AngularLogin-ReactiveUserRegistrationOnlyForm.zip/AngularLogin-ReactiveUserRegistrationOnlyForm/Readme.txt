1. npm install bootstrap@4 jquery --save
2. Install
npm install ngx-toastr --save
@angular/animations package is a required dependency for the default toast
npm install @angular/animations --save