﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPI_without_EF.Models
{
    public class EmpClass1
    {
        public int EmpId { get; set; }
        public string EmpFirstname { get; set; }
        public string EmpLastname { get; set; }
        public string EmpGender { get; set; }
        public int EmpSalary { get; set; }
    }
}