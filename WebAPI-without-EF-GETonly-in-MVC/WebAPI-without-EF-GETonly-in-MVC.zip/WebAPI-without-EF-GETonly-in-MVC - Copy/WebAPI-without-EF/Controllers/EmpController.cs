﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using WebAPI_without_EF.Models;

namespace WebAPI_without_EF.Controllers  // MVC WebApi
{   ////http://localhost:52892/api/Emp
    public class EmpController : ApiController
    {
        public IHttpActionResult getEmp()
        {
            List<EmpClass1> ec = new List<EmpClass1>();
            string mainConn = ConfigurationManager.ConnectionStrings["Myconnection"].ConnectionString;
            SqlConnection sqlConn = new SqlConnection(mainConn);
            sqlConn.Open();
            string sqlQuery = "select * from [dbo].[Employees]";
            SqlCommand sqlComm = new SqlCommand(sqlQuery, sqlConn);
            SqlDataReader sdr = sqlComm.ExecuteReader();
            while (sdr.Read())
            {
                ec.Add(new EmpClass1()
                {
                    EmpId = Convert.ToInt32(sdr.GetValue(0)),
                    EmpFirstname = sdr.GetValue(1).ToString(),
                    EmpLastname = sdr.GetValue(2).ToString(),
                    EmpGender = sdr.GetValue(3).ToString(),
                    EmpSalary = Convert.ToInt32(sdr.GetValue(4))
                });
            }
            return Ok(ec); // Results will be on XML format
        }
    }
}
