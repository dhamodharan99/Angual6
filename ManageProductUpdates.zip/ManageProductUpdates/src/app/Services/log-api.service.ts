import { Injectable, DebugElement } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Log } from '../Classes/Log';

@Injectable()
export class LogApiService {
  baseUrl: "http://localhost:3000/Logs";
  constructor(private httpclient: HttpClient) { }

  getLogHistory(): Observable<Log[]> {
    debugger;
    return this.httpclient.get<Log[]>("http://localhost:3000/Logs")
      // .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error :', errorResponse.error.message);
    } else {
      console.error('Server Side Error :', errorResponse);
    }
    return throwError('There is a problem with the service. We are notified & working on it. Please try again later.');
  }


}
