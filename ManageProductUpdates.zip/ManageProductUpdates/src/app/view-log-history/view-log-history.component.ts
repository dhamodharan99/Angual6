import { Component, OnInit } from '@angular/core';
import { Log } from '../Classes/Log';
import { Router } from '@angular/router';
import { LogApiService } from '../Services/log-api.service';

@Component({
  selector: 'app-view-log-history',
  templateUrl: './view-log-history.component.html',
  styleUrls: ['./view-log-history.component.css']
})
export class ViewLogHistoryComponent implements OnInit {
  updates: Log[];

  constructor(private _updateService: LogApiService,
                private _router: Router) { }
  ngOnInit() {
    this._updateService.getLogHistory().subscribe(
      (updatesList) => this.updates = updatesList,
      (err) => console.log(err)
    );
  }
  editButtonClick(employeeId: number) {
    this._router.navigate(['/edit', employeeId]);
  }

}
