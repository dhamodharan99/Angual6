import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-log-details',
  templateUrl: './add-log-details.component.html',
  styleUrls: ['./add-log-details.component.css']
})
export class AddLogDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
