import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLogDetailsComponent } from './add-log-details.component';

describe('AddLogDetailsComponent', () => {
  let component: AddLogDetailsComponent;
  let fixture: ComponentFixture<AddLogDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddLogDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLogDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
