import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewLogHistoryComponent } from './view-log-history/view-log-history.component';
import { AddLogDetailsComponent } from './add-log-details/add-log-details.component';


const appRoutes: Routes = [
      { path: 'list', component: ViewLogHistoryComponent },
      { path: 'create', component: AddLogDetailsComponent },
      { path: '', redirectTo: '/list', pathMatch: 'full' }
    ];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
