import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http'
import { Routes, RouterModule } from '@angular/router';
     
import { ViewLogHistoryComponent } from './view-log-history/view-log-history.component';
import { AddLogDetailsComponent } from './add-log-details/add-log-details.component';
import { LogApiService } from './Services/log-api.service';

const appRoutes: Routes = [
    { path: 'list', component: ViewLogHistoryComponent },
    { path: 'create', component: AddLogDetailsComponent },
    { path: '', redirectTo: '/list', pathMatch: 'full' }
  ];
@NgModule({
  declarations: [
    AppComponent,
    ViewLogHistoryComponent,
    AddLogDetailsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,  RouterModule.forRoot(appRoutes)
  ],
  providers: [LogApiService],
  bootstrap: [AppComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
