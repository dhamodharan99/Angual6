

export class Log{
id : number;
title : string;
content : string;
logTypeId : number;
userId : number
loggedTime : string;
}



