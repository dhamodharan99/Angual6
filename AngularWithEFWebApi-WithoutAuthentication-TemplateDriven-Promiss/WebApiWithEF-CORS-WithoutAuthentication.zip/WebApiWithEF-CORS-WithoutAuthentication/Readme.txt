------------------------- Entity framework - EF
Code first approach steps:
1. Add-Migration "InitialCreate"
2. Update-Database

Install-Package Microsoft.VisualStudio.Web.CodeGeneration.Design -Version 3.1.1
-----------------------