1. node -v
2. npm install -g @angular/cli
3. ng -v
4. ng new AngularCrud
5. cd AngularCrud
6. npm install ngx-bootstrap --save
npm install bootstrap@3 --save
7. Once Bootstrap is installed, open .angular-cli.json file and specify the path to the Bootstrap stylesheet (bootstrap.min.css) in the styles property as shown below.
"styles": [
 "src/styles.css",
  "node_modules/bootstrap/dist/css/bootstrap.min.css",
  "node_modules/ngx-bootstrap/datepicker/bs-datepicker.css"
]
R