export class Employee {
    ID: number;
    FirstName: string;
    LastName: string;
    Gender: string;
    Salary: string;
}
